# 👑 تحدي العائلة - تطبيق أندرويد

تطبيق أندرويد للعبة "تحدي العائلة" — لعبة أسئلة وأجوبة تنافسية بين فريقين، تحتوي على 204+ سؤال موزعة على 6 فئات.

## 🚀 طريقة الحصول على ملف APK (بدون أي إعداد محلي)

هذا المشروع يبني تطبيق الأندرويد **تلقائياً** على خوادم GitHub باستخدام GitHub Actions، فلا تحتاج تثبيت Android Studio أو أي أدوات على جهازك.

### الخطوات:

1. **ارفع هذا المجلد إلى مستودع GitHub جديد:**
   - أنشئ مستودع (repository) جديد على GitHub
   - ارفع كل ملفات هذا المجلد إليه (إما عبر الموقع مباشرة بالسحب والإفلات، أو عبر `git push`)

2. **انتظر البناء التلقائي:**
   - بمجرد رفع الملفات على فرع `main`، سيبدأ GitHub تلقائياً ببناء التطبيق
   - تابع التقدم من تبويب **Actions** في صفحة المستودع

3. **حمّل ملف APK:**
   - بعد اكتمال البناء (يأخذ حوالي 3-5 دقائق)، اذهب إلى تبويب **Releases** في المستودع
   - ستجد إصدار جديد يحتوي على ملف `app-release.apk`
   - حمّله مباشرة على جهاز الأندرويد

   **أو بديل:** من تبويب **Actions**، افتح آخر عملية بناء ناجحة، وحمّل الملف من قسم **Artifacts**

4. **ثبّت التطبيق:**
   - افتح ملف APK على جهاز الأندرويد
   - إذا طلب منك السماح بالتثبيت من "مصادر غير معروفة"، وافق
   - استمتع باللعبة! 🎉

## 📂 رفع المشروع عبر سطر الأوامر (git)

```bash
cd family-challenge-android
git init
git add .
git commit -m "تحدي العائلة - أول إصدار"
git branch -M main
git remote add origin https://github.com/USERNAME/REPO_NAME.git
git push -u origin main
```

استبدل `USERNAME/REPO_NAME` برابط مستودعك.

## 🛠️ البناء يدوياً (اختياري - لمن يملك Android Studio)

1. افتح المجلد في Android Studio
2. اضغط على **Run** أو **Build > Build Bundle(s) / APK(s) > Build APK(s)**
3. ستجد الملف الناتج في: `app/build/outputs/apk/debug/app-debug.apk`

## 📁 هيكل المشروع

```
family-challenge-android/
├── app/
│   ├── src/main/
│   │   ├── assets/www/index.html    ← ملف اللعبة (HTML/CSS/JS)
│   │   ├── java/.../MainActivity.java  ← يعرض اللعبة داخل WebView
│   │   ├── res/                      ← أيقونات وألوان التطبيق
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── .github/workflows/build.yml      ← أتمتة البناء على GitHub
├── build.gradle
└── settings.gradle
```

## ✏️ تعديل اللعبة

كل محتوى اللعبة (الأسئلة، التصميم، المنطق) موجود في ملف واحد:
```
app/src/main/assets/www/index.html
```

عدّل هذا الملف، ثم ارفع التغييرات (`git push`) — سيُعاد بناء APK جديد تلقائياً.

## 📝 ملاحظات

- التطبيق يعمل بدون إنترنت (كل شيء محلي داخل التطبيق)
- مبني على WebView، خفيف الحجم وسريع
- يدعم اللغة العربية بالكامل (RTL)
